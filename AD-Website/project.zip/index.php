<!-- the header includes the same navigation bar on every page -->
<?php 
    include_once 'header.php';
?>

<div class="universe-body">

</div>

<div class="index-second">
    <p>
        Act 1:
        Sera comes back home to her apartment after a day of work. When she walks into her apartment she finds a strange anomaly in her living room. Alarmed though curious Sera decides to investigate the situation.
        <br>
        <br>
        As she carefully walks up to its mirror like surface, strange particles start flowing from the floor and other surfaces of the room. The anomaly, standing only feet away from Sera, convulses and suddenly extends towards Sera in the blink of an eye.
        <br>
        <br>
        Sera tries to free herself of the anomaly's grasp. Excruciating pain engulfs her as she tries to rip the glassy like tendrils off her arm. She falls to the ground as she gasps for air that was suddenly no longer there..
    </p>
</div>

<?php
    include_once 'footer.php';
?>
<!-- footer provides same content on every page -->