UPDATES:
-import.sql aangemaakt
-Documentatie beschikbaar gemaakt (ook meer in readme)
-Ongebruikte files uit .zip gehaald
-Kleine security verbeteringen

TODO:
-Op een lokale xampp instantie, ga naar localhost/phpmyadmin in de url en ga naar import. Kies als file de meegeleverde import.sql om de database aan te maken die nodig is voor de website om zijn functionaliteit lokaal uit te voeren.

Hierbij de eerste versie van de Among Dreamers (AD) website als mijn eindproject. Het is een soort eigen Tolkien-achtig universum dat ik samen met een maatje aan het maken ben. Denk Lord of the Rings meets Cyberpunk 2077 meets League of Legends met muziek videos en volledig geschreven verhaal.

Ik heb dit gekozen omdat ik dit ook echt ga gebruiken, alleen is de uiteindelijke scope te groot om binnen een paar weken helemaal af te krijgen, echter hoop ik dat het genoeg is om te slagen voor deze opleiding.

Wat ik in deze website wilde bouwen zijn: 
-Parallax scrolling index pagina
<!-- -Login systeem -->
-Profiel pagina voor de ingelogde gebruiker
<!-- -Log uit functie -->
<!-- -Muziek pagina -->
-Product paginas
-Uitcheck paginas
-Favoriet systeem om producten op te kunnen slaan
-Cookie consent melding

Wat ik nog niet af heb gekregen (en dus later toe ga voegen) zijn:
-Parallax scrolling index pagina
-Product paginas
-Uitcheck paginas
-Favoriet systeem om producten op te kunnen slaan
-Profiel pagina voor de ingelogde gebruiker
-Cookie consent melding

Er zijn een paar files in de zip die de uiteindelijke functionaliteit moesten ondersteunen, die nu nog niet in gebruik zijn. Dit heb ik zo gedaan omdat de coach zei dat ik beter geen incomplete website aan kon leveren. Met wat meer front end had het er beter uit gezien, maar ik koos ervoor de nadruk meer te leggen op de functionaliteit.

Toelichtingen:
-In de database code is er gebruik gemaakt van mysqli functies ipv mysql. Mysqli is een geupdate versie die veiliger is voor web development en daarom koos ik er voor. Verder heb ik qua security onder andere gebruik gemaakt van password hashes en prepared statements.
-Ik wilde toch laten zien dat ik veel geleerd had van de CSS lessen. Daarom heb ik ook voor dit onderwerp onder andere een restore.css gemaakt. Hiermee overscrhijf ik als eerst de standaard browser CSS om dezelfde uitstraling op alle browsers mee kan geven. Ook zijn er leuke kleine dingetjes zoals de achtergrond dat een eigen projectis, geloopt als .gif.

Tot slot:
Ik vond het een erg leuke opleiding en ik heb ontzettend veel geleerd over web dev. Daarom hoop ik ook zeker terug te komen naar bit-academy om nog meer te leren hier over. Veel dank voor de community coaches en slack community die de reis naar het eindproject aanzienlijk hebben geholpen! :) 

Technieken toegepast:
-POST
-GET
