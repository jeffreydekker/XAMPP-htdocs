<?php 
    include_once 'header.php';
?>

<p>Discover the AD sound and collaborations</p>
<div class="spotify-iframe">
    <iframe style="border-radius:12px" src="https://open.spotify.com/embed/playlist/3jQNAkX7WOaI929LMGwsOW?utm_source=generator" width="50%" height="600px" frameBorder="50%" allowfullscreen="no"; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
</div>

<?php
    include_once 'footer.php';
?>
